(() => {
  // packages/adapter-schema/src/runtime.ts
  var utf8 = new TextEncoder();
  var INPUT_LIMIT = 64 * 1024;
  var OUTPUT_LIMIT = 256 * 1024;
  function parsePattern(pattern) {
    const m = /^(https?):\/\/([a-z0-9.-]+)(\/[^?#]*)$/.exec(pattern);
    if (!m || m[2] === "*" || m[1] === "http" && m[2] !== "localhost")
      throw new Error(
        "Use HTTPS and an exact host, or HTTP localhost for development."
      );
    const u = new URL(`${m[1]}://${m[2]}/`);
    if (u.hostname !== m[2] || !m[2].includes(".") && m[2] !== "localhost")
      throw new Error("Invalid host");
    return { protocol: m[1], host: m[2], path: m[3] };
  }
  function matchesUrl(pattern, url) {
    try {
      const p = parsePattern(pattern), u = new URL(url);
      return u.protocol === p.protocol + ":" && u.hostname === p.host && new RegExp(
        "^" + p.path.split("*").map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$"
      ).test(u.pathname);
    } catch {
      return false;
    }
  }
  function assertInput(tool, input) {
    if (!input || typeof input !== "object" || Array.isArray(input))
      throw new Error("Input must be an object");
    if (utf8.encode(JSON.stringify(input)).length > INPUT_LIMIT)
      throw new Error("Input exceeds 64 KiB");
    const schema = tool.inputSchema, result = /* @__PURE__ */ Object.create(null);
    for (const key of schema.required ?? [])
      if (!Object.hasOwn(input, key)) throw new Error(`Missing input: ${key}`);
    for (const [key, v] of Object.entries(input)) {
      if (!Object.hasOwn(schema.properties, key))
        throw new Error(`Unexpected input: ${key}`);
      const p = schema.properties[key];
      if (p.type === "integer" ? typeof v !== "number" || !Number.isSafeInteger(v) : typeof v !== p.type)
        throw new Error(`Invalid type: ${key}`);
      if (typeof v === "number" && !Number.isFinite(v))
        throw new Error(`Invalid number: ${key}`);
      if (p.enum && !p.enum.some((x) => x === v))
        throw new Error(`Invalid enum: ${key}`);
      if (typeof v === "string" && p.type === "string" && (p.minLength !== void 0 && [...v].length < p.minLength || p.maxLength !== void 0 && [...v].length > p.maxLength))
        throw new Error(`Invalid length: ${key}`);
      if (typeof v === "number" && (p.type === "number" || p.type === "integer") && (p.minimum !== void 0 && v < p.minimum || p.maximum !== void 0 && v > p.maximum))
        throw new Error(`Out of range: ${key}`);
      result[key] = v;
    }
    return result;
  }

  // packages/runtime-webmcp/src/index.ts
  function getModelContext(doc = document, nav = navigator) {
    for (const target of [doc, nav]) {
      const c = Reflect.get(target, "modelContext");
      if (c && typeof c.registerTool === "function") return c;
    }
    return void 0;
  }
  async function registerTools(context, tools, signal) {
    const owned = [];
    const names = new Set(
      (await context.getTools?.() ?? []).map((t) => t.name)
    );
    for (const tool of tools) {
      if (signal.aborted) break;
      if (names.has(tool.name)) continue;
      try {
        await context.registerTool(tool, { signal });
        names.add(tool.name);
        owned.push(tool.name);
      } catch (e) {
        if (e instanceof DOMException && ["SecurityError", "NotAllowedError"].includes(e.name))
          throw e;
        if (e instanceof Error && /already|duplicate/i.test(e.message)) continue;
        throw e;
      }
    }
    return owned;
  }

  // packages/adapter-sdk/src/index.ts
  var ToolGraftError = class extends Error {
    code;
    hint;
    constructor(code, message, hint = "Reload the page and try again.") {
      super(message);
      this.code = code;
      this.hint = hint;
    }
  };
  function textResult(value) {
    let s = typeof value === "string" ? value : JSON.stringify(value);
    if (utf8.encode(s).length > OUTPUT_LIMIT - 128) {
      s = new TextDecoder().decode(utf8.encode(s).subarray(0, OUTPUT_LIMIT - 128)) + "\n[TRUNCATED: output exceeds 256 KiB]";
    }
    return { content: [{ type: "text", text: s }] };
  }
  function errorResult(error) {
    const e = error instanceof ToolGraftError ? error : new ToolGraftError(
      "TOOL_FAILED",
      error instanceof Error ? error.message : "Tool failed"
    );
    return {
      ...textResult({ code: e.code, message: e.message, hint: e.hint }),
      isError: true
    };
  }
  function defineAdapter(adapter) {
    return adapter;
  }
  function confirmWrite(adapterId, tool, input) {
    return new Promise((resolve, reject) => {
      const port = chrome.runtime.connect({ name: "toolgraft-confirm" });
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        port.disconnect();
        ok ? resolve() : reject(
          new ToolGraftError(
            "CONFIRMATION_DENIED",
            "The operation was not approved.",
            "Call the tool again and approve the operation in ToolGraft."
          )
        );
      };
      const timer = setTimeout(() => finish(false), 12e4);
      port.onMessage.addListener((m) => finish(m?.approved === true));
      port.onDisconnect.addListener(() => finish(false));
      port.postMessage({ adapterId, tool, input });
    });
  }
  function startAdapter(adapter, manifest) {
    let controller;
    let last = "";
    let rebuilding = Promise.resolve();
    const active = /* @__PURE__ */ new Set();
    const check = () => {
      const url = location.href;
      if (url === last) return;
      last = url;
      rebuilding = rebuilding.then(async () => {
        controller?.abort();
        controller = new AbortController();
        if (!manifest.matches.some((p) => matchesUrl(p, location.href))) return;
        const context = getModelContext();
        if (!context) {
          diagnostic(
            "blocked",
            "WebMCP is unavailable. Enable the WebMCP flags in a supported Chrome build."
          );
          return;
        }
        const registrationController = controller;
        const tools = adapter.tools.map((tool) => ({
          ...tool,
          execute: async (input) => {
            try {
              if (!manifest.matches.some((p) => matchesUrl(p, location.href)))
                throw new ToolGraftError(
                  "UNSUPPORTED_PAGE",
                  "This tool is not available on this route."
                );
              const allowed = await chrome.runtime.sendMessage({
                type: "authorize-call",
                adapterId: manifest.id,
                version: manifest.version
              }).catch(() => false);
              if (!allowed)
                throw new ToolGraftError(
                  "ADAPTER_NOT_READY",
                  "This adapter is no longer active.",
                  "Review adapter status and reload the page."
                );
              let args;
              try {
                args = assertInput(tool, input);
              } catch (e) {
                throw new ToolGraftError(
                  "VALIDATION_ERROR",
                  String(e),
                  "Check the input against the tool schema."
                );
              }
              if (active.has(tool.name))
                throw new ToolGraftError(
                  "ADAPTER_NOT_READY",
                  "This tool already has an invocation in progress.",
                  "Wait for it to finish."
                );
              active.add(tool.name);
              try {
                if (!tool.annotations.readOnlyHint || tool.annotations.destructiveHint)
                  await confirmWrite(manifest.id, tool.name, args);
                if (registrationController.signal.aborted || !manifest.matches.some((p) => matchesUrl(p, location.href)))
                  throw new ToolGraftError(
                    "UNSUPPORTED_PAGE",
                    "The page changed during confirmation."
                  );
                const result = await tool.execute(args);
                return textResultResult(result);
              } finally {
                active.delete(tool.name);
              }
            } catch (e) {
              return errorResult(e);
            }
          }
        }));
        try {
          const registered = await registerTools(
            context,
            tools,
            controller.signal
          );
          diagnostic(
            "active",
            `${registered.length} tools registered`,
            registered
          );
        } catch (e) {
          controller.abort();
          diagnostic("blocked", String(e));
        }
      }).catch((e) => diagnostic("broken", String(e)));
    };
    function diagnostic(state, message, tools = []) {
      void chrome.runtime.sendMessage({
        type: "diagnostic",
        adapterId: manifest.id,
        state,
        message,
        tools
      }).catch(() => {
      });
    }
    check();
    const timer = manifest.routeScoped ? setInterval(check, 250) : void 0;
    const stop = () => {
      controller?.abort();
      if (timer) clearInterval(timer);
    };
    addEventListener("pagehide", stop, { once: true });
    addEventListener("popstate", check);
    return stop;
  }
  function textResultResult(v) {
    if (v && typeof v === "object" && "content" in v) {
      const result = v;
      return {
        ...textResult(result.content.map((c) => c.text).join("\n")),
        ...result.isError ? { isError: true } : {}
      };
    }
    return textResult(v);
  }

  // adapters/wikipedia/src/index.ts
  var empty = {
    type: "object",
    properties: {},
    additionalProperties: false
  };
  function content() {
    const root = document.querySelector("#mw-content-text .mw-parser-output");
    if (!root)
      throw new ToolGraftError(
        "PAGE_SHAPE_CHANGED",
        "Article content is missing.",
        "Open an English Wikipedia article."
      );
    return root;
  }
  var src_default = defineAdapter({
    tools: [
      {
        name: "wikipedia_current_page",
        description: "Read this Wikipedia article title, canonical URL, and bounded introduction.",
        inputSchema: empty,
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: () => {
          const c = content();
          return textResult({
            title: document.querySelector("#firstHeading")?.textContent,
            url: document.querySelector("link[rel=canonical]")?.href ?? location.href,
            summary: [
              ...(c.querySelector('section[data-mw-section-id="0"]') ?? c).querySelectorAll("p")
            ].map((p) => p.textContent?.trim() ?? "").filter(Boolean).slice(0, 5).join("\n").slice(0, 12e3)
          });
        }
      },
      {
        name: "wikipedia_section_text",
        description: "Read bounded text from a named article section.",
        inputSchema: {
          ...empty,
          properties: {
            section: { type: "string", minLength: 1, maxLength: 200 }
          },
          required: ["section"]
        },
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: ({ section }) => {
          const c = content();
          const heading = [...c.querySelectorAll("h2,h3")].find(
            (h) => h.textContent?.trim().toLowerCase() === String(section).toLowerCase()
          );
          if (!heading)
            throw new ToolGraftError(
              "PAGE_SHAPE_CHANGED",
              "Section not found.",
              "Use an exact visible section heading."
            );
          let node = (heading.closest(".mw-heading") ?? heading).nextElementSibling;
          let text = "";
          while (node && !node.matches("h2,h3,.mw-heading") && text.length < 2e4) {
            text += (node.textContent ?? "") + "\n";
            node = node.nextElementSibling;
          }
          return textResult({
            title: String(section),
            url: location.href,
            text: text.slice(0, 2e4)
          });
        }
      },
      {
        name: "wikipedia_search",
        description: "Search English Wikipedia and return up to five article titles and links.",
        inputSchema: {
          ...empty,
          properties: { query: { type: "string", minLength: 1, maxLength: 200 } },
          required: ["query"]
        },
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: async ({ query }) => {
          const url = new URL("/w/api.php", location.origin);
          url.search = new URLSearchParams({
            action: "opensearch",
            format: "json",
            limit: "5",
            search: String(query)
          }).toString();
          const r = await fetch(url, {
            credentials: "omit",
            redirect: "error",
            signal: AbortSignal.timeout(1e4)
          });
          if (!r.ok)
            throw new ToolGraftError(
              r.status === 429 ? "RATE_LIMITED" : "NETWORK_ERROR",
              `Search returned ${r.status}.`
            );
          const result = await r.json();
          if (!Array.isArray(result) || !Array.isArray(result[1]) || !Array.isArray(result[3]))
            throw new ToolGraftError(
              "PAGE_SHAPE_CHANGED",
              "Search response changed."
            );
          return textResult(
            result[1].map((title, i) => ({
              title,
              url: result[3][i]
            }))
          );
        }
      }
    ]
  });

  // adapter-bootstrap.ts
  startAdapter(src_default, { "compatibility": { "minEngine": 1, "minExtension": "0.1.0" }, "description": "Tools for Wikipedia.", "id": "community.wikipedia", "license": "MIT", "matches": ["https://en.wikipedia.org/wiki/*", "https://en.wikipedia.org/w/*"], "payloadSha256": "0000000000000000000000000000000000000000000000000000000000000000", "permissions": { "hosts": ["https://en.wikipedia.org/*"], "network": "same-origin", "pageStorage": false }, "routeScoped": true, "runtime": { "entry": "bundle.js", "kind": "script", "runAt": "document_idle", "world": "USER_SCRIPT" }, "schemaVersion": 1, "source": "https://github.com/particular-labs/toolgraft", "title": "Wikipedia", "tools": [{ "annotations": { "readOnlyHint": true, "untrustedContentHint": true }, "description": "Read this Wikipedia article title, canonical URL, and bounded introduction.", "inputSchema": { "additionalProperties": false, "properties": {}, "type": "object" }, "name": "wikipedia_current_page" }, { "annotations": { "readOnlyHint": true, "untrustedContentHint": true }, "description": "Read bounded text from a named article section.", "inputSchema": { "additionalProperties": false, "properties": { "section": { "maxLength": 200, "minLength": 1, "type": "string" } }, "required": ["section"], "type": "object" }, "name": "wikipedia_section_text" }, { "annotations": { "readOnlyHint": true, "untrustedContentHint": true }, "description": "Search English Wikipedia and return up to five article titles and links.", "inputSchema": { "additionalProperties": false, "properties": { "query": { "maxLength": 200, "minLength": 1, "type": "string" } }, "required": ["query"], "type": "object" }, "name": "wikipedia_search" }], "version": "0.1.1" });
})();
