(() => {
  // packages/adapter-schema/src/runtime.ts
  var utf8 = new TextEncoder();
  var INPUT_LIMIT = 64 * 1024;
  var OUTPUT_LIMIT = 256 * 1024;
  function parsePattern(pattern) {
    const m = /^(https?):\/\/([a-z0-9.-]+)(\/[^?#]*)$/.exec(pattern);
    if (!m || m[2] === "*" || m[1] === "http" && m[2] !== "localhost")
      throw new Error(
        "Use HTTPS and an exact host, or HTTP localhost for development."
      );
    const u = new URL(`${m[1]}://${m[2]}/`);
    if (u.hostname !== m[2] || !m[2].includes(".") && m[2] !== "localhost")
      throw new Error("Invalid host");
    return { protocol: m[1], host: m[2], path: m[3] };
  }
  function matchesUrl(pattern, url) {
    try {
      const p = parsePattern(pattern), u = new URL(url);
      return u.protocol === p.protocol + ":" && u.hostname === p.host && new RegExp(
        "^" + p.path.split("*").map((s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*") + "$"
      ).test(u.pathname);
    } catch {
      return false;
    }
  }
  function assertInput(tool, input) {
    if (!input || typeof input !== "object" || Array.isArray(input))
      throw new Error("Input must be an object");
    if (utf8.encode(JSON.stringify(input)).length > INPUT_LIMIT)
      throw new Error("Input exceeds 64 KiB");
    const schema = tool.inputSchema, result = /* @__PURE__ */ Object.create(null);
    for (const key of schema.required ?? [])
      if (!Object.hasOwn(input, key)) throw new Error(`Missing input: ${key}`);
    for (const [key, v] of Object.entries(input)) {
      if (!Object.hasOwn(schema.properties, key))
        throw new Error(`Unexpected input: ${key}`);
      const p = schema.properties[key];
      if (p.type === "integer" ? typeof v !== "number" || !Number.isSafeInteger(v) : typeof v !== p.type)
        throw new Error(`Invalid type: ${key}`);
      if (typeof v === "number" && !Number.isFinite(v))
        throw new Error(`Invalid number: ${key}`);
      if (p.enum && !p.enum.some((x) => x === v))
        throw new Error(`Invalid enum: ${key}`);
      if (typeof v === "string" && p.type === "string" && (p.minLength !== void 0 && [...v].length < p.minLength || p.maxLength !== void 0 && [...v].length > p.maxLength))
        throw new Error(`Invalid length: ${key}`);
      if (typeof v === "number" && (p.type === "number" || p.type === "integer") && (p.minimum !== void 0 && v < p.minimum || p.maximum !== void 0 && v > p.maximum))
        throw new Error(`Out of range: ${key}`);
      result[key] = v;
    }
    return result;
  }

  // packages/runtime-webmcp/src/index.ts
  function getModelContext(doc = document, nav = navigator) {
    for (const target of [doc, nav]) {
      const c = Reflect.get(target, "modelContext");
      if (c && typeof c.registerTool === "function") return c;
    }
    return void 0;
  }
  async function registerTools(context, tools, signal) {
    const owned = [];
    const names = new Set(
      (await context.getTools?.() ?? []).map((t) => t.name)
    );
    for (const tool of tools) {
      if (signal.aborted) break;
      if (names.has(tool.name)) continue;
      try {
        await context.registerTool(tool, { signal });
        names.add(tool.name);
        owned.push(tool.name);
      } catch (e) {
        if (e instanceof DOMException && ["SecurityError", "NotAllowedError"].includes(e.name))
          throw e;
        if (e instanceof Error && /already|duplicate/i.test(e.message)) continue;
        throw e;
      }
    }
    return owned;
  }

  // packages/adapter-sdk/src/index.ts
  var ToolGraftError = class extends Error {
    code;
    hint;
    constructor(code, message, hint = "Reload the page and try again.") {
      super(message);
      this.code = code;
      this.hint = hint;
    }
  };
  function textResult(value) {
    let s = typeof value === "string" ? value : JSON.stringify(value);
    if (utf8.encode(s).length > OUTPUT_LIMIT - 128) {
      s = new TextDecoder().decode(utf8.encode(s).subarray(0, OUTPUT_LIMIT - 128)) + "\n[TRUNCATED: output exceeds 256 KiB]";
    }
    return { content: [{ type: "text", text: s }] };
  }
  function errorResult(error) {
    const e = error instanceof ToolGraftError ? error : new ToolGraftError(
      "TOOL_FAILED",
      error instanceof Error ? error.message : "Tool failed"
    );
    return {
      ...textResult({ code: e.code, message: e.message, hint: e.hint }),
      isError: true
    };
  }
  function defineAdapter(adapter) {
    return adapter;
  }
  function confirmWrite(adapterId, tool, input) {
    return new Promise((resolve, reject) => {
      const port = chrome.runtime.connect({ name: "toolgraft-confirm" });
      let done = false;
      const finish = (ok) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        port.disconnect();
        ok ? resolve() : reject(
          new ToolGraftError(
            "CONFIRMATION_DENIED",
            "The operation was not approved.",
            "Call the tool again and approve the operation in ToolGraft."
          )
        );
      };
      const timer = setTimeout(() => finish(false), 12e4);
      port.onMessage.addListener((m) => finish(m?.approved === true));
      port.onDisconnect.addListener(() => finish(false));
      port.postMessage({ adapterId, tool, input });
    });
  }
  function startAdapter(adapter, manifest) {
    let controller;
    let last = "";
    let rebuilding = Promise.resolve();
    const active = /* @__PURE__ */ new Set();
    const check = () => {
      const url = location.href;
      if (url === last) return;
      last = url;
      rebuilding = rebuilding.then(async () => {
        controller?.abort();
        controller = new AbortController();
        if (!manifest.matches.some((p) => matchesUrl(p, location.href))) return;
        const context = getModelContext();
        if (!context) {
          diagnostic(
            "blocked",
            "WebMCP is unavailable. Enable the WebMCP flags in a supported Chrome build."
          );
          return;
        }
        const registrationController = controller;
        const tools = adapter.tools.map((tool) => ({
          ...tool,
          execute: async (input) => {
            try {
              if (!manifest.matches.some((p) => matchesUrl(p, location.href)))
                throw new ToolGraftError(
                  "UNSUPPORTED_PAGE",
                  "This tool is not available on this route."
                );
              const allowed = await chrome.runtime.sendMessage({
                type: "authorize-call",
                adapterId: manifest.id,
                version: manifest.version
              }).catch(() => false);
              if (!allowed)
                throw new ToolGraftError(
                  "ADAPTER_NOT_READY",
                  "This adapter is no longer active.",
                  "Review adapter status and reload the page."
                );
              let args;
              try {
                args = assertInput(tool, input);
              } catch (e) {
                throw new ToolGraftError(
                  "VALIDATION_ERROR",
                  String(e),
                  "Check the input against the tool schema."
                );
              }
              if (active.has(tool.name))
                throw new ToolGraftError(
                  "ADAPTER_NOT_READY",
                  "This tool already has an invocation in progress.",
                  "Wait for it to finish."
                );
              active.add(tool.name);
              try {
                if (!tool.annotations.readOnlyHint || tool.annotations.destructiveHint)
                  await confirmWrite(manifest.id, tool.name, args);
                if (registrationController.signal.aborted || !manifest.matches.some((p) => matchesUrl(p, location.href)))
                  throw new ToolGraftError(
                    "UNSUPPORTED_PAGE",
                    "The page changed during confirmation."
                  );
                const result = await tool.execute(args);
                return textResultResult(result);
              } finally {
                active.delete(tool.name);
              }
            } catch (e) {
              return errorResult(e);
            }
          }
        }));
        try {
          const registered = await registerTools(
            context,
            tools,
            controller.signal
          );
          diagnostic(
            "active",
            `${registered.length} tools registered`,
            registered
          );
        } catch (e) {
          controller.abort();
          diagnostic("blocked", String(e));
        }
      }).catch((e) => diagnostic("broken", String(e)));
    };
    function diagnostic(state, message, tools = []) {
      void chrome.runtime.sendMessage({
        type: "diagnostic",
        adapterId: manifest.id,
        state,
        message,
        tools
      }).catch(() => {
      });
    }
    check();
    const timer = manifest.routeScoped ? setInterval(check, 250) : void 0;
    const stop = () => {
      controller?.abort();
      if (timer) clearInterval(timer);
    };
    addEventListener("pagehide", stop, { once: true });
    addEventListener("popstate", check);
    return stop;
  }
  function textResultResult(v) {
    if (v && typeof v === "object" && "content" in v) {
      const result = v;
      return {
        ...textResult(result.content.map((c) => c.text).join("\n")),
        ...result.isError ? { isError: true } : {}
      };
    }
    return textResult(v);
  }

  // adapters/playground/src/index.ts
  var empty = {
    type: "object",
    properties: {},
    additionalProperties: false
  };
  var idInput = {
    ...empty,
    properties: { id: { type: "string", minLength: 1, maxLength: 50 } },
    required: ["id"]
  };
  function root() {
    const r = document.querySelector('[data-toolgraft-tasks="v1"]');
    if (!r)
      throw new ToolGraftError(
        "PAGE_SHAPE_CHANGED",
        "The task list is missing or not ready.",
        "Wait for rendering or reset the markup scenario."
      );
    return r;
  }
  function tasks() {
    return [...root().querySelectorAll("[data-task-id]")].map(
      (row) => ({
        id: row.dataset.taskId,
        title: row.querySelector("[data-title]").textContent,
        completed: row.dataset.completed === "true"
      })
    );
  }
  function signedIn() {
    if (document.documentElement.dataset.session !== "signed-in")
      throw new ToolGraftError(
        "AUTH_REQUIRED",
        "The demo session is signed out.",
        "Use Sign in to demo on the playground."
      );
  }
  function find(id) {
    const result = tasks().find((t) => t.id === id);
    if (!result)
      throw new ToolGraftError(
        "UNSUPPORTED_PAGE",
        "No task with this ID.",
        "List tasks and choose an existing ID."
      );
    return result;
  }
  var src_default = defineAdapter({
    tools: [
      {
        name: "playground_list_tasks",
        description: "List the synthetic playground tasks.",
        inputSchema: empty,
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: () => textResult(tasks())
      },
      {
        name: "playground_get_task",
        description: "Read one playground task by ID.",
        inputSchema: idInput,
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: ({ id }) => textResult(find(String(id)))
      },
      {
        name: "playground_create_task",
        description: "Create one synthetic task after approval.",
        inputSchema: {
          ...empty,
          properties: { title: { type: "string", minLength: 1, maxLength: 200 } },
          required: ["title"]
        },
        annotations: { readOnlyHint: false, untrustedContentHint: true },
        execute: ({ title }) => {
          signedIn();
          root();
          const input = document.querySelector("#title");
          const form = document.querySelector("#create");
          if (!input || !form)
            throw new ToolGraftError(
              "PAGE_SHAPE_CHANGED",
              "Create form is missing."
            );
          input.value = String(title);
          form.requestSubmit();
          return textResult(tasks().at(-1));
        }
      },
      {
        name: "playground_complete_task",
        description: "Complete a task after approval.",
        inputSchema: idInput,
        annotations: { readOnlyHint: false, untrustedContentHint: true },
        execute: ({ id }) => {
          signedIn();
          find(String(id));
          const button = [
            ...root().querySelectorAll("[data-complete]")
          ].find((b) => b.dataset.complete === id);
          if (!button)
            throw new ToolGraftError(
              "PAGE_SHAPE_CHANGED",
              "Complete button is missing."
            );
          button.click();
          return textResult(find(String(id)));
        }
      },
      {
        name: "playground_reset",
        description: "Reset all synthetic tasks to their initial values.",
        inputSchema: empty,
        annotations: {
          readOnlyHint: false,
          destructiveHint: true,
          untrustedContentHint: true
        },
        execute: () => {
          signedIn();
          root();
          const reset = document.querySelector("#reset");
          if (!reset)
            throw new ToolGraftError(
              "PAGE_SHAPE_CHANGED",
              "Reset control is missing."
            );
          reset.click();
          return textResult(tasks());
        }
      }
    ]
  });

  // adapter-bootstrap.ts
  startAdapter(src_default, { "compatibility": { "minEngine": 1, "minExtension": "0.1.0" }, "description": "Tools for ToolGraft playground.", "id": "community.playground", "license": "MIT", "matches": ["http://localhost/tasks*", "http://localhost/"], "payloadSha256": "0000000000000000000000000000000000000000000000000000000000000000", "permissions": { "hosts": ["http://localhost/*"], "network": "same-origin", "pageStorage": false }, "routeScoped": true, "runtime": { "entry": "bundle.js", "kind": "script", "runAt": "document_idle", "world": "USER_SCRIPT" }, "schemaVersion": 1, "source": "https://github.com/particular-labs/toolgraft", "title": "ToolGraft playground", "tools": [{ "annotations": { "readOnlyHint": true, "untrustedContentHint": true }, "description": "List the synthetic playground tasks.", "inputSchema": { "additionalProperties": false, "properties": {}, "type": "object" }, "name": "playground_list_tasks" }, { "annotations": { "readOnlyHint": true, "untrustedContentHint": true }, "description": "Read one playground task by ID.", "inputSchema": { "additionalProperties": false, "properties": { "id": { "maxLength": 50, "minLength": 1, "type": "string" } }, "required": ["id"], "type": "object" }, "name": "playground_get_task" }, { "annotations": { "readOnlyHint": false, "untrustedContentHint": true }, "description": "Create one synthetic task after approval.", "inputSchema": { "additionalProperties": false, "properties": { "title": { "maxLength": 200, "minLength": 1, "type": "string" } }, "required": ["title"], "type": "object" }, "name": "playground_create_task" }, { "annotations": { "readOnlyHint": false, "untrustedContentHint": true }, "description": "Complete a task after approval.", "inputSchema": { "additionalProperties": false, "properties": { "id": { "maxLength": 50, "minLength": 1, "type": "string" } }, "required": ["id"], "type": "object" }, "name": "playground_complete_task" }, { "annotations": { "destructiveHint": true, "readOnlyHint": false, "untrustedContentHint": true }, "description": "Reset all synthetic tasks to their initial values.", "inputSchema": { "additionalProperties": false, "properties": {}, "type": "object" }, "name": "playground_reset" }], "version": "0.1.0" });
})();
